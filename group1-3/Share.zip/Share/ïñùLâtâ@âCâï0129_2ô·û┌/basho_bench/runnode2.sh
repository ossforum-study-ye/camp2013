#!/bin/sh

./basho_bench ./bb_config/2node/01_2node_put_1kx1.config
./basho_bench ./bb_config/2node/02_2node_get_1kx1.config
./basho_bench ./bb_config/2node/03_2node_put_1kx10.config
./basho_bench ./bb_config/2node/04_2node_get_1kx10.config
./basho_bench ./bb_config/2node/05_2node_put_100kx1.config
./basho_bench ./bb_config/2node/06_2node_get_100kx1.config
./basho_bench ./bb_config/2node/07_2node_put_100kx10.config
./basho_bench ./bb_config/2node/08_2node_get_100kx10.config

