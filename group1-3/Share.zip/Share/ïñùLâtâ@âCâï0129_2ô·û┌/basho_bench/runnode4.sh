#!/bin/sh

./basho_bench ./bb_config/4node/01_4node_put_1kx1.config
./basho_bench ./bb_config/4node/02_4node_get_1kx1.config
./basho_bench ./bb_config/4node/03_4node_put_1kx10.config
./basho_bench ./bb_config/4node/04_4node_get_1kx10.config
./basho_bench ./bb_config/4node/05_4node_put_100kx1.config
./basho_bench ./bb_config/4node/06_4node_get_100kx1.config
./basho_bench ./bb_config/4node/07_4node_put_100kx10.config
./basho_bench ./bb_config/4node/08_4node_get_100kx10.config

