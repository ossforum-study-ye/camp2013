#!/bin/sh

./basho_bench ./bb_config/1node/01_1node_put_1kx1.config
./basho_bench ./bb_config/1node/02_1node_get_1kx1.config
./basho_bench ./bb_config/1node/03_1node_put_1kx10.config
./basho_bench ./bb_config/1node/04_1node_get_1kx10.config
./basho_bench ./bb_config/1node/05_1node_put_100kx1.config
./basho_bench ./bb_config/1node/06_1node_get_100kx1.config
./basho_bench ./bb_config/1node/07_1node_put_100kx10.config
./basho_bench ./bb_config/1node/08_1node_get_100kx10.config

